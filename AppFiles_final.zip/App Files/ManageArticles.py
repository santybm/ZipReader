import sqlite3 as lite

def addArticle(title, string):
	try:
		con = lite.connect('zipData')
		
		with con:
			cur = con.cursor()
			cur.execute("""INSERT INTO articles(ID,Name,Content) VALUES (?,?,?);""", (None, title, string))
		con.close
		return (True)
	
	except ValueError:
		return (False)

def deleteArticle(title):
	try:
		con = lite.connect('zipData')
		with con:
			cur = con.cursor()
			cur.execute("""DELETE FROM articles WHERE Name = '%s';""" % (title))
		con.close
		return (True)
	except ValueError:
		return (False)
	
def selectAllArtileIDs():
	ids = []
	try:
		con = lite.connect('zipData')
		with con:
			cur = con.cursor()
			cur.execute('SELECT ID FROM articles')
			for row in cur.fetchall():
				ids.append(row[0])
		con.close
		return (ids)
	except ValueError:
		return(False)
		
def getArticleContent(aID):
	try:
		con = lite.connect('zipData')
		with con:
			cur = con.cursor()
			cur.execute("""SELECT Content FROM articles WHERE ID = '%s';""" % (aID))
			for row in cur.fetchone():
				return(row)
			con.close
	except ValueError:
		return(False)
		

		
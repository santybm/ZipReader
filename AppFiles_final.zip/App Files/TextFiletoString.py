# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

fileHandle = open ( 'data.txt', 'r' )
str = fileHandle.read()
fileHandle.close()
a = str

